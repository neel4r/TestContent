//
//  Message+CoreDataClass.swift
//  iOS-10-Sampler
//
//  Created by Noritaka Kamiya on 2016/08/31.
//  Copyright © 2016 Noritaka Kamiya. All rights reserved.
//

import Foundation
import CoreData

@objc(Message)
public class Message: NSManagedObject {

}
